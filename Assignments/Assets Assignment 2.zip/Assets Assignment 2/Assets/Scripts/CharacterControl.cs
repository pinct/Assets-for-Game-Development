﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterControl : MonoBehaviour
{
    //Animator anim;
    //bool jump = false;
    Animator anim;
    public bool isInvincible = false;
    int isJumping = Animator.StringToHash("isJumping");
    int isAttacking = Animator.StringToHash("isAttacking");
    int isCrouching = Animator.StringToHash("isCrouching");
    public int lives = 3;
    float sprint = 0.5f;
    public GameObject livesText;
    //float timeLeft = 3.0f;
    // do later var runStateHash : int = Animator.StringToHash("Base Layer.Run");

    void Start()
    {
        //anim = GetComponent<Animator>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {


        //    float horizontalMove = Input.GetAxis("Horizontal");
        //    anim.SetFloat("Speed", Mathf.Abs(horizontalMove));
        //    anim.SetBool("JumpButonPressed", jump);
        if (!Input.GetKey(KeyCode.LeftControl))
        {
            float move = Input.GetAxis("Horizontal");
            anim.SetFloat("Speed", Mathf.Abs(move) * sprint);
            Movement();
        }
        else
        {
            anim.SetFloat("Speed", 0);
        }

        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);
        if (Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetTrigger(isJumping);
        }
        else if (Input.GetKeyDown(KeyCode.F))
        {
            anim.SetTrigger(isAttacking);
            isInvincible = true;
            
        }
        else if (Input.GetKeyUp(KeyCode.F))
        {
            anim.ResetTrigger(isAttacking);
            isInvincible = false;
        }
        else if (Input.GetKeyDown(KeyCode.LeftControl))
        {
            anim.SetTrigger(isCrouching);
        }
        else if (Input.GetKeyUp(KeyCode.LeftControl))
        {
            anim.ResetTrigger(isCrouching);
            anim.SetBool("initialCrouch", false);
        }

        livesText.GetComponent<Text>().text = $"Lives: {lives}";
    }

    void Movement()
    {
        if (Input.GetKey(KeyCode.LeftShift))
        {
            sprint = 1f;
        }
        else
        {
            sprint = 0.5f;
        }
        if (Input.GetKey(KeyCode.D))
        {
            GetComponent<SpriteRenderer>().flipX = false;
            transform.Translate(Vector2.right * 3f * Time.deltaTime * sprint);
            transform.eulerAngles = new Vector2(0, 0);
        }
        if (Input.GetKey(KeyCode.A))
        {
            GetComponent<SpriteRenderer>().flipX = true;
            transform.Translate(Vector2.left * 3f * Time.deltaTime * sprint);
            transform.eulerAngles = new Vector2(0, 0);
        }
        if (Input.GetButtonDown("Jump"))
        {
            transform.Translate(Vector2.up * 10f * Time.deltaTime);
        }
    }
}
