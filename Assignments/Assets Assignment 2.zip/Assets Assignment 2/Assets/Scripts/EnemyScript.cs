﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnemyScript : MonoBehaviour
{
    float timeLeft = 1.0f;
    Vector2 direction = Vector2.left;
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(direction * 3f * Time.deltaTime);
        transform.eulerAngles = new Vector2(0, 0);

        timeLeft -= Time.deltaTime;
        if(timeLeft <= 0)
        {
            if (direction == Vector2.left)
            {
                direction = Vector2.right;
                GetComponent<SpriteRenderer>().flipX = true;
                timeLeft = 1.0f;
            }
            else
            {
                direction = Vector2.left;
                GetComponent<SpriteRenderer>().flipX = false;
                timeLeft = 1.0f;
            }
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player" && !collision.gameObject.GetComponent<CharacterControl>().isInvincible)
        {
            collision.gameObject.GetComponent<CharacterControl>().lives -= 1;
            if (collision.gameObject.GetComponent<CharacterControl>().lives == 0)
            {
                collision.gameObject.GetComponent<CharacterControl>().livesText.GetComponent<Text>().text = "Game Over";
                Destroy(collision.gameObject);
            }
        }
        else if (collision.gameObject.tag == "Player" && collision.gameObject.GetComponent<CharacterControl>().isInvincible)
        {
            Destroy(gameObject);
        }
    }
}
